package com.example.kinopoisk_10;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Arrays;

public class Film implements Parcelable {

    private String _name;
    private String _description;
    private String _tagLine;
    public String _director;
    private String[] _genres;
    public int _releaseYear;
    private int _duration;
    private long _views;
    private long _ratingsSum;
    private String _posterURI;
    private String _trailerURI;

    public String getName() {
        return _name;
    }

    public String getDescription() {
        return _description;
    }

    public String getTagLine() {
        return _tagLine;
    }

    public String getDirector() { return _director; }

    public String[] getGenres() {
        return _genres;
    }

    public int getReleaseYear() {
        return _releaseYear;
    }

    public int getDuration() {
        return _duration;
    }

    public long getViews() {
        return _views;
    }

    public long getRatingsSum() {
        return _ratingsSum;
    }

    public String getPosterURI() { return _posterURI; }

    public String getTrailerURI() { return _trailerURI; }

    public Film(String name, String description, String tagLine, String director, String[] genres,
                int releaseYear, int duration, long views, long ratingsSum, String posterURI) {
        _name = name;
        _description = description;
        _tagLine = tagLine;
        _director = director;
        _genres = Arrays.copyOf(genres, genres.length);
        _releaseYear = releaseYear;
        _duration = duration;
        _views = views;
        _ratingsSum = ratingsSum;
        _posterURI = posterURI;
        _trailerURI = null;
    }

    public Film(String name, String description, String tagLine, String director, String[] genres,
                int releaseYear, int duration, long views, long ratingsSum, String posterURI, String trailerURI) {

        this(name, description, tagLine, director, genres, releaseYear, duration, views, ratingsSum, posterURI);

        if (trailerURI != null && !trailerURI.isEmpty())
            _trailerURI = trailerURI;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    // упаковываем объект в Parcel
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(_name);
        parcel.writeString(_description);
        parcel.writeString(_tagLine);
        parcel.writeString(_director);
        parcel.writeStringArray(_genres);
        parcel.writeInt(_releaseYear);
        parcel.writeInt(_duration);
        parcel.writeLong(_views);
        parcel.writeLong(_ratingsSum);
        parcel.writeString(_posterURI);
        parcel.writeString(_trailerURI);
    }

    public static final Parcelable.Creator<Film> CREATOR = new Parcelable.Creator<Film>() {
        // распаковываем объект из Parcel
        public Film createFromParcel(Parcel in) {
            return new Film(in);
        }

        public Film[] newArray(int size) {
            return new Film[size];
        }
    };

    // конструктор, считывающий данные из Parcel
    private Film(Parcel parcel) {
        _name = parcel.readString();
        _description = parcel.readString();
        _tagLine = parcel.readString();
        _director = parcel.readString();
        _genres = parcel.createStringArray();
        _releaseYear = parcel.readInt();
        _duration = parcel.readInt();
        _views = parcel.readLong();
        _ratingsSum = parcel.readLong();
        _posterURI = parcel.readString();
        _trailerURI = parcel.readString();
    }

}
