package com.example.kinopoisk_10;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import java.util.Objects;

public class FilmAddingDialogFragment extends DialogFragment {

    private static final boolean DEFAULT_ADD_FILM_CHECKBOX_STATE = false;

    private static final String DEFAULT_NAME_EDIT_TEXT = "Новый фильмец";
    private static final String DEFAULT_DESCRIPTION_EDIT_TEXT = "Невероятный фильм про невероятные вещи!!!";
    private static final String DEFAULT_TAG_LINE_EDIT_TEXT = "Это просто фильм";
    private static final String DEFAULT_DIRECTOR_EDIT_TEXT = "Алексей Абраменко";
    private static final String DEFAULT_GENRES_EDIT_TEXT = "комедия,экшен,боевик";

    private static final int DEFAULT_RELEASE_YEAR_EDIT_TEXT = 2020;
    private static final int DEFAULT_DURATION_EDIT_TEXT = 122;

    private static final long DEFAULT_VIEWS_EDIT_TEXT = 1000;
    private static final long DEFAULT_RATING_SUM_EDIT_TEXT = 10000;

    private static final String DEFAULT_POSTER_URI_EDIT_TEXT = "1704946/ef31cdd5-e056-4acf-be7b-45344e1c7b53/x1000";
    private static final String DEFAULT_TRAILER_URI_EDIT_TEXT = null;

    private static final Boolean DEFAULT_IS_ADDING_FILM_CHECKBOX_STATE = false;

    private String _currentFilmName;
    private String _currentFilmDescription;
    private String _currentFilmTagLine;
    private String _currentFilmDirector;
    private String _currentFilmGenres;

    private int _currentFilmReleaseYear;
    private String _currentFilmReleaseYearString;
    private int _currentFilmDuration;
    private String _currentFilmDurationString;

    private long _currentFilmViews;
    private String _currentFilmViewsString;
    private long _currentFilmRatingsSum;
    private String _currentFilmRatingsSumString;

    private String _currentFilmPosterURI;
    private String _currentFilmTrailerURI;

    private String[] _currentFilmGenresArray;

    private Boolean _isAddingFilm;


    public String getCurrentFilmName() { return _currentFilmName; }

    public String getCurrentFilmDescription() { return _currentFilmDescription; }

    public String getCurrentFilmTagLine() { return _currentFilmTagLine; }

    public String getCurrentFilmDirector() { return _currentFilmDirector; }

    public String getCurrentFilmGenres() { return _currentFilmGenres; }

    public int getCurrentFilmReleaseYear() { return _currentFilmReleaseYear; }

    public int getCurrentFilmDuration() { return _currentFilmDuration; }

    public long getCurrentFilmViews() { return _currentFilmViews; }

    public long getCurrentFilmRatingsSum() { return _currentFilmRatingsSum; }

    public String getCurrentFilmPosterURI() { return _currentFilmPosterURI; }

    public String getCurrentFilmTrailerURI() { return _currentFilmTrailerURI; }

    public String[] getCurrentFilmGenresArray() { return _currentFilmGenresArray; }

    public Boolean getIsAddingFilm() { return  _isAddingFilm; }


    public FilmAddingDialogFragment() {
        _currentFilmName = DEFAULT_NAME_EDIT_TEXT;
        _currentFilmDescription = DEFAULT_DESCRIPTION_EDIT_TEXT;
        _currentFilmTagLine = DEFAULT_TAG_LINE_EDIT_TEXT;
        _currentFilmDirector = DEFAULT_DIRECTOR_EDIT_TEXT;
        _currentFilmGenres = DEFAULT_GENRES_EDIT_TEXT;

        _currentFilmReleaseYear = DEFAULT_RELEASE_YEAR_EDIT_TEXT;
        _currentFilmReleaseYearString = Integer.toString(_currentFilmReleaseYear);
        _currentFilmDuration = DEFAULT_DURATION_EDIT_TEXT;
        _currentFilmDurationString = Integer.toString(_currentFilmDuration);

        _currentFilmViews = DEFAULT_VIEWS_EDIT_TEXT;
        _currentFilmViewsString = Long.toString(_currentFilmViews);
        _currentFilmRatingsSum = DEFAULT_RATING_SUM_EDIT_TEXT;
        _currentFilmRatingsSumString = Long.toString(_currentFilmRatingsSum);

        _currentFilmPosterURI = DEFAULT_POSTER_URI_EDIT_TEXT;
        _currentFilmTrailerURI = DEFAULT_TRAILER_URI_EDIT_TEXT;

        _isAddingFilm = DEFAULT_IS_ADDING_FILM_CHECKBOX_STATE;

        _currentFilmGenresArray = null;

        getGenresStringToArray();
    }


    public interface FilmAddingNoticeDialogListener {
        public void onFilmAddingDialogPositiveClick(DialogFragment dialog);
        public void onFilmAddingDialogNegativeClick(DialogFragment dialog);
    }

    private FilmAddingNoticeDialogListener _listener;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            _listener = (FilmAddingNoticeDialogListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString()
                    + " must implement NoticeDialogListener");
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();

        View currentView = inflater.inflate(R.layout.film_adding_item_constraint, null);

        final EditText nameEditText = currentView.findViewById(R.id.film_adding_edit_text_name);
        final EditText descriptionEditText = currentView.findViewById(R.id.film_adding_edit_text_description);
        final EditText tagLineEditText = currentView.findViewById(R.id.film_adding_edit_text_tag_line);
        final EditText directorEditText = currentView.findViewById(R.id.film_adding_edit_text_director);
        final EditText genresEditText = currentView.findViewById(R.id.film_adding_edit_text_genres);
        final EditText releaseYearEditText = currentView.findViewById(R.id.film_adding_edit_text_release_year);
        final EditText durationEditText = currentView.findViewById(R.id.film_adding_edit_text_duration);
        final EditText viewsEditText = currentView.findViewById(R.id.film_adding_edit_text_views);
        final EditText ratingSumEditText = currentView.findViewById(R.id.film_adding_edit_text_ratings_sum);
        final EditText posterURIEditText = currentView.findViewById(R.id.film_adding_edit_text_poster_URI);
        final EditText trailerURIEditText = currentView.findViewById(R.id.film_adding_edit_text_trailer_URI);

        final CheckBox isAddingFilmCheckBox = currentView.findViewById(R.id.film_adding_checkbox_add_film);

        nameEditText.setText(_currentFilmName);
        descriptionEditText.setText(_currentFilmDescription);
        tagLineEditText.setText(_currentFilmTagLine);
        directorEditText.setText(_currentFilmDirector);
        genresEditText.setText(_currentFilmGenres);
        releaseYearEditText.setText(_currentFilmReleaseYearString);
        durationEditText.setText(_currentFilmDurationString);
        viewsEditText.setText(_currentFilmViewsString);
        ratingSumEditText.setText(_currentFilmRatingsSumString);
        posterURIEditText.setText(_currentFilmPosterURI);
        trailerURIEditText.setText(_currentFilmTrailerURI);

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        builder.setView(currentView)
                // Add action buttons
                .setPositiveButton(R.string.positive_push, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {

                        _currentFilmName = nameEditText.getText().toString();
                        _currentFilmDescription = descriptionEditText.getText().toString();
                        _currentFilmTagLine = tagLineEditText.getText().toString();
                        _currentFilmDirector = directorEditText.getText().toString();
                        _currentFilmGenres = genresEditText.getText().toString();

                        _currentFilmReleaseYearString = releaseYearEditText.getText().toString();

                        if (_currentFilmReleaseYearString.isEmpty())
                            _currentFilmReleaseYear = 0;

                        _currentFilmDurationString = durationEditText.getText().toString();

                        if (_currentFilmDurationString.isEmpty())
                            _currentFilmDuration = 0;

                        _currentFilmViewsString = viewsEditText.getText().toString();

                        if (_currentFilmViewsString.isEmpty())
                            _currentFilmViews = 0;

                        _currentFilmRatingsSumString = ratingSumEditText.getText().toString();

                        if (_currentFilmRatingsSumString.isEmpty())
                            _currentFilmRatingsSum = 0;

                        _currentFilmPosterURI = posterURIEditText.getText().toString();
                        _currentFilmTrailerURI = trailerURIEditText.getText().toString();

                        _isAddingFilm = isAddingFilmCheckBox.isChecked();

                        _listener.onFilmAddingDialogPositiveClick(FilmAddingDialogFragment.this);
                    }
                })
                .setNegativeButton(R.string.negative_push, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        _listener.onFilmAddingDialogNegativeClick(FilmAddingDialogFragment.this);
                    }
                });

        return builder.create();
    }

    private void getGenresStringToArray() {
        if (_currentFilmGenres == null)
            return;

        if (_currentFilmGenres.isEmpty())
            return;

        String[] allGenres = _currentFilmGenres.split(",");

        int validAmount = 0;

        for (int i = 0; i < allGenres.length; i++)
            if (allGenres[i] != null && !allGenres[i].isEmpty())
                validAmount++;

        _currentFilmGenresArray = new String[validAmount];
        int j = 0;

        for (int i = 0; i < allGenres.length; i++) {
            if (allGenres[i] != null && !allGenres[i].isEmpty()) {
                _currentFilmGenresArray[j] = allGenres[i];
                j++;
            }
        }

    }

}
