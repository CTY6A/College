package com.example.kinopoisk_10;

public final class Config {

    private Config() {
    }

    public static final String YOUTUBE_API_KEY = "AIzaSyBECTFPL3znTBXAqfZRg954xAyGN9qvQV4";

}