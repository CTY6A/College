package com.example.kinopoisk_10;

public final class AllConstants {

    public static final String POSTER_URI_START = "https://avatars.mds.yandex.net/get-kinopoisk-image/";

    private AllConstants() {}

}
