package com.example.kinopoisk_10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;

public class FilmInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_info_constraint);

        Bundle extras = getIntent().getExtras();
        if (extras == null)
            return;

        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        ImageView filmImage;
        TextView textViewAboutFilm;

        Film currentFilm = getIntent().getParcelableExtra(Film.class.getCanonicalName());

        filmImage = (ImageView) findViewById(R.id.film_info_image);
        Glide.with(this.getApplicationContext()).load(AllConstants.POSTER_URI_START + currentFilm.getPosterURI()).into(filmImage);

        textViewAboutFilm = findViewById(R.id.film_info_name);
        textViewAboutFilm.setText(currentFilm.getName());

        setTitle(currentFilm.getName());

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_tag_line);
        textViewAboutFilm.setText(currentFilm.getTagLine());

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_release_year);
        textViewAboutFilm.setText(String.valueOf(currentFilm.getReleaseYear()));

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_director);
        textViewAboutFilm.setText(currentFilm.getDirector());

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_genres);
        textViewAboutFilm.setText(genresToString(currentFilm.getGenres()));

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_duration);
        textViewAboutFilm.setText(String.valueOf(currentFilm.getDuration()));

        long ratingSum = currentFilm.getRatingsSum();
        long views = currentFilm.getViews();
        double filmRating = (double)ratingSum / views;
        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_rating);
        textViewAboutFilm.setText(decimalFormat.format(filmRating));

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_about_views);
        textViewAboutFilm.setText(String.valueOf(views));

        textViewAboutFilm = (TextView) findViewById(R.id.film_info_text_view_description);
        textViewAboutFilm.setText(currentFilm.getDescription());

        final String videoURI = currentFilm.getTrailerURI();

        if (videoURI != null) {
            Button playButton = findViewById(R.id.film_info_play_button);
            playButton.setVisibility(View.VISIBLE);

            playButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(FilmInfoActivity.this, YoutubeActivity.class);
                    intent.putExtra("YoutubeURI", videoURI);
                    startActivity(intent);
                }
            });

            TextView videoInfo = findViewById(R.id.film_info_text_view_no_video);
            videoInfo.setVisibility(View.GONE);
        }

    }

    private String genresToString(String[] genres) {
        String result = "";
        for (int i = 0; i < genres.length; i++) {
            result += genres[i];
            if (i != genres.length - 1)
                result += ", ";
        }
        return result;
    }

}
