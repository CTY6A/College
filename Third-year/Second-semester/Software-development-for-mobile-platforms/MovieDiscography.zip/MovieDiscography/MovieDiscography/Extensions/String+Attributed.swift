//
//  String+Attributed.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

extension String {
    
    var attributed: NSAttributedString {
        
        return NSAttributedString(string: self,
                                  attributes: [.font : FontsManager.shared.currentFont()])
    }
}
