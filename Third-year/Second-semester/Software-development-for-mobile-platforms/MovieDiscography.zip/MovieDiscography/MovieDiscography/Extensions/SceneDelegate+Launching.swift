//
//  SceneDelegate+Launching.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

extension SceneDelegate {
    
    func makeWindow(_ scene: UIWindowScene) {
        
        window = UIWindow(windowScene: scene)
        window?.rootViewController = MainNavigationController(rootViewController: DiscographyViewController())
        window?.makeKeyAndVisible()
    }
}
