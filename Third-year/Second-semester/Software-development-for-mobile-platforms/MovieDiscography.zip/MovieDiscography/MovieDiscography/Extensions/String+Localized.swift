//
//  String+Localized.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

extension String {
    
    var localized: String {
        return NSLocalizedString(self, comment: "")
    }
}
