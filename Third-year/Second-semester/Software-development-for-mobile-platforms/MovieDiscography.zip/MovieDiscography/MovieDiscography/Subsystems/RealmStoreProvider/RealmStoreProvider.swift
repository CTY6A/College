//
//  RealmStoreProvider.swift
//  MovieDiscography
//
//  Created by local.home on 5/8/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation
import RealmSwift

class MovieObject: Object {
    
    @objc dynamic var filmName: String = ""
    @objc dynamic var filmId: String = ""
    @objc dynamic var releaseDate: String = ""
    @objc dynamic var filmTrailer: String = ""
    @objc dynamic var movieDescription: String = ""
    @objc dynamic var poster: String = ""
}

class RealmStoreProvider {
    
    static let shared = RealmStoreProvider()
    
    private let realm = try! Realm()
    
    var movies: Results<MovieObject>?
    
    init() {
        
        read()
    }
}

extension RealmStoreProvider {
    
    private func read() {
        
        autoreleasepool {
            
            movies = { realm.objects(MovieObject.self) }()
        }
    }
    
    func writeToStore(object: MovieObject) {
        
        autoreleasepool {
            do {
                try  realm.write {
                    realm.add(object)
                }
            } catch {}
        }
    }
}
