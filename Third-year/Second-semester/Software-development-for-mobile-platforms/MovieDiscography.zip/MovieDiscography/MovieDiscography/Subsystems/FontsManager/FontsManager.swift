//
//  FontsManager.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

enum FontsUserDefualtsKey: String {
    
    case currentFontName = "currentFontName"
    case currentFontSize = "currentFontSize"
}

struct FontsManager {
    
    static let shared = FontsManager()
    
    func currentFont() -> UIFont {
        
        if let fontName = UserDefaults.standard.object(forKey: FontsUserDefualtsKey.currentFontName.rawValue) as? String,
            let fontSize = UserDefaults.standard.object(forKey: FontsUserDefualtsKey.currentFontSize.rawValue) as? CGFloat,
            let font = UIFont(name: fontName, size: fontSize) {
            
            return font
        }
        
        if let fontName = UIFont.fontNames(forFamilyName: "Avenir").first {
            
            if let font = UIFont(name: fontName, size: 15.0) {
                saveFont(font)
                
                return font
            }
        }
        
        let font = UIFont.systemFont(ofSize: 15.0)
        saveFont(font)
        
        return font
    }
    
    func saveFont(_ font: UIFont?) {
         
        let fontName = font?.fontName
        let fontSize = font?.pointSize
        
        UserDefaults.standard.set(fontName, forKey: FontsUserDefualtsKey.currentFontName.rawValue)
        UserDefaults.standard.set(fontSize, forKey: FontsUserDefualtsKey.currentFontSize.rawValue)
    }
}
