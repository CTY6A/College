//
//  LanguageManager.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

enum LanguageUserDefualtsKey: String {
    
    case internalLanguageCode = "internalLanguageCode"
    case devicePreviousLanguageCode = "previousLanguageCode"
    case deviceInternalLanguageCode = "00"
    case defaultLanguageCode = "en"
    case appleLanguages = "AppleLanguages"
    case languageChangedNotification = "LanguageChangedNotification"
}

struct LanguageManager {
    
    static let shared = LanguageManager()
    
    func setupCurrentLanguage() {
        
        guard let currentLanguage = internalLanguageCode() else {
            
            let localizationLanguages = availableLocalizationLanguages()
            
            let prefferedLanguages = UserDefaults.standard.object(forKey: LanguageUserDefualtsKey.appleLanguages.rawValue)
            
            //check if device system language exist at localizations
            
            if (localizationLanguages.contains(deviceLanguageCode())) {
                
                UserDefaults.standard.setValue(deviceLanguageCode(),
                                               forKey: LanguageUserDefualtsKey.devicePreviousLanguageCode.rawValue)
                
                saveInternalLanguageCode(code: LanguageUserDefualtsKey.deviceInternalLanguageCode.rawValue)
                changeCurrentAppLanguageCode(to: deviceLanguageCode())
                
            } else {
                
                // determine app language code
                
                var findedLanguage: String?
                
                guard let prefferedLanguageArray = prefferedLanguages as? [String] else {
                    
                    findedLanguage = LanguageUserDefualtsKey.defaultLanguageCode.rawValue
                    saveInternalLanguageCode(code: findedLanguage!)
                    changeCurrentAppLanguageCode(to: findedLanguage!)
                    return
                    
                }
                
                for language in prefferedLanguageArray {
                    
                    if (localizationLanguages.contains(language)) {
                        
                        findedLanguage = language
                        break
                    }
                }
                saveInternalLanguageCode(code: findedLanguage!)
                changeCurrentAppLanguageCode(to: findedLanguage!)
            }
            
            return
        }
        
        // check on device language changing if selected device language
        
        if (currentLanguage == LanguageUserDefualtsKey.deviceInternalLanguageCode.rawValue &&
            UserDefaults.standard.object(forKey: LanguageUserDefualtsKey.devicePreviousLanguageCode.rawValue) as?
                String? != deviceLanguageCode()) {
            
            setDeviceLanguageCode()
        }
        
        UserDefaults.standard.setValue(deviceLanguageCode(), forKey: LanguageUserDefualtsKey.devicePreviousLanguageCode.rawValue)
    }
    
    func deviceLanguageCode() -> String {
        return String(NSLocale.current.identifier.prefix(2))
    }
    
    func currentLanguageCode() -> String {
        
        let selectedLanguageCode = internalLanguageCode()
        
        if selectedLanguageCode == LanguageUserDefualtsKey.deviceInternalLanguageCode.rawValue {
            
            return deviceLanguageCode()
            
        } else {
            
            return selectedLanguageCode!
        }
    }
    
    func availableLanguageList() -> [String] {
        
        var resultArray = [String]()
        
        let localizationList = availableLocalizationLanguages()
        
        for langCode in localizationList {
            
            let customLocale = NSLocale(localeIdentifier: langCode)
            
            let language = String(format: "%@ (%@)", customLocale.displayName(forKey: NSLocale.Key.identifier,
                                                                              value: langCode.capitalized)!,
                                  langCode.uppercased())
            
            resultArray.append(language)
        }
        
        return resultArray
    }
    
    func currentLanguageString() -> String {
        
        let customLocale = NSLocale(localeIdentifier: currentLanguageCode())
        
        let language = String(format: "%@ (%@)", customLocale.displayName(forKey: NSLocale.Key.identifier,
                                                                          value: currentLanguageCode().capitalized)!,
                              currentLanguageCode().uppercased())
        return language
    }
    
    func currentLanguageIndex() -> Int {
        
        var index = 0
        
        if internalLanguageCode() != LanguageUserDefualtsKey.deviceInternalLanguageCode.rawValue {
            
            guard let languageIndex = availableLocalizationLanguages().firstIndex(of: currentLanguageCode()) else {
                return index
            }
            index = languageIndex
        }
        return index
    }
    
    func changeCurrentAppLanguageCode(to code: String) {
        
        let prefferedLanguages = UserDefaults.standard.object(forKey: LanguageUserDefualtsKey.appleLanguages.rawValue) as? [String]
        
        guard let prefferedLangArray = prefferedLanguages else {
            return
        }
        
        var filteredPrefferedLanguages = prefferedLangArray.filter { $0 != code }
        filteredPrefferedLanguages.insert(code, at: 0)
        
        UserDefaults.standard.setValue(filteredPrefferedLanguages, forKey: LanguageUserDefualtsKey.appleLanguages.rawValue)
    }
    
    func saveLanguage(by index: Int) {
        
        let code = availableLocalizationLanguages()[index]
        
        saveInternalLanguageCode(code: code)
        changeCurrentAppLanguageCode(to: code)
        
        Bundle.set(language: code)
    }
    
    // MARK: - Private methods
    
    private func internalLanguageCode() -> String? {
        
        guard let languageCode = UserDefaults.standard.object(forKey: LanguageUserDefualtsKey.internalLanguageCode.rawValue) as? String else {
            return "00"
        }
        
        return languageCode
    }
    
    private func setDeviceLanguageCode() {
        
        let localizationLanguages = availableLanguageList()
        
        var currentLanguage = deviceLanguageCode()
        
        // determine app language code
        
        if (!localizationLanguages.contains(currentLanguage)) {
            
            currentLanguage = LanguageUserDefualtsKey.defaultLanguageCode.rawValue
        }
        
        changeCurrentAppLanguageCode(to: currentLanguage)
    }
    
    private func availableLocalizationLanguages() -> [String] {
        
        return ["de", "en", "ru"]
    }
    
    private func saveInternalLanguageCode(code: String) {
        
        UserDefaults.standard.setValue(code, forKey: LanguageUserDefualtsKey.internalLanguageCode.rawValue)
        
    }
}
