//
//  MediumEntity.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct MediumEntity {
    
    var filmImage: String?
}

// MARK: - Decodable

extension MediumEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case filmImage = "film_image"
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        if container.contains(.filmImage) {
            filmImage = try container.decode(String?.self, forKey: .filmImage)
        }
    }
}
