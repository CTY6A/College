//
//  OneEntiy.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct OneEntity {
    
    var medium: MediumEntity?
}

// MARK: - Decodable

extension OneEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case medium = "medium"
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        if container.contains(.medium) {
            medium = try container.decode(MediumEntity?.self, forKey: .medium)
        }
    }
}
