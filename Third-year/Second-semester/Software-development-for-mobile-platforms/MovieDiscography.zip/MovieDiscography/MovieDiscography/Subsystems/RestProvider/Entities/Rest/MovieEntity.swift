//
//  FilmEntity.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct MovieEntity {
    
    var filmName: String?
    var filmId: String?
    var releaseDates: [ReleaseDateEntity]?
    var filmTrailer: String?
    var description: String?
    var images: ImagesEntity?
}

// MARK: - Decodable

extension MovieEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case filmName = "film_name"
        case filmId = "film_id"
        case releaseDates = "release_dates"
        case filmTrailer = "film_trailer"
        case description = "synopsis_long"
        case images
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        if container.contains(.filmName) {
            filmName = try container.decode(String?.self, forKey: .filmName)
        }
        if container.contains(.filmId) {
            do {
                filmId = try container.decode(String?.self, forKey: .filmId)
            } catch {
                
                filmId = "\(Date().hashValue)"
            }
        }
        if container.contains(.releaseDates) {
            releaseDates = try container.decode([ReleaseDateEntity]?.self, forKey: .releaseDates)
        }
        if container.contains(.filmTrailer) {
            filmTrailer = try container.decode(String?.self, forKey: .filmTrailer)
        }
        if container.contains(.description) {
            description = try container.decode(String?.self, forKey: .description)
        }
        if container.contains(.images) {
            images = try container.decode(ImagesEntity?.self, forKey: .images)
        }
    }
}
