//
//  ImagesEntity.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct ImagesEntity {
    
    var poster: PosterEntity?
}

// MARK: - Decodable

extension ImagesEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case poster
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        if container.contains(.poster) {
            poster = try container.decode(PosterEntity?.self, forKey: .poster)
        }
    }
}
