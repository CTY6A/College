//
//  PosterEntity.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct PosterEntity {
    
    var oneEntity: OneEntity?
}

// MARK: - Decodable

extension PosterEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case oneEntity = "1"
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        do {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            if container.contains(.oneEntity) {
                oneEntity = try container.decode(OneEntity?.self, forKey: .oneEntity)
            }
        } catch {
            
            return
        }
    }
}
