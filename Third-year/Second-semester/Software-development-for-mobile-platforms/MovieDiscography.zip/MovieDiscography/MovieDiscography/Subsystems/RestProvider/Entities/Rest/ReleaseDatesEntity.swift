//
//  ReleaseDatesEntity.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct ReleaseDateEntity {
    
    var releaseDate: String?
    var notes: String?
}

// MARK: - Decodable

extension ReleaseDateEntity: Codable {
    
    // MARK: - CodingKey
    
    private enum CodingKeys: String, CodingKey {
        
        case releaseDate = "release_date"
        case notes = "notes"
    }
    
    // MARK: - Initialization
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        if container.contains(.releaseDate) {
            releaseDate = try container.decode(String?.self, forKey: .releaseDate)
        }
        if container.contains(.notes) {
            notes = try container.decode(String?.self, forKey: .notes)
        }
    }
}
