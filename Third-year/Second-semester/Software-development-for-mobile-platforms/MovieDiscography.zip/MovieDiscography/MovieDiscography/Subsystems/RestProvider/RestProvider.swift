//
//  RestProvider.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation
import Alamofire
import FirebaseFirestore

struct RestProvider {
    
    static let shared = RestProvider()
    
    private let imageCache = NSCache<NSString, UIImage>()
    private let videoCache = NSCache<NSString, NSURL>()
    
    private let fireStore = Firestore.firestore()
}

typealias MovieRequestSuccessful = ([Movie]) -> Void

// MARK: - Movies

extension RestProvider {
    
    func requestMovies(successful: @escaping MovieRequestSuccessful) {
        
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        
        let headers: HTTPHeaders = ["api-version" : "v200",
                                    "Authorization" : "Basic QlNVSToyUzFmekhGeFZGSFk=",
                                    "x-api-key" : "9YVGnvpUzy3dHsn9kHHVl6RHa8SYXxkX1sAVQySK",
                                    "device-datetime" : formatter.string(from: Date()),
                                    "territory" : "UK",
                                    "client" : "BSUI"]
        
        AF.request("https://api-gate2.movieglu.com/filmsNowShowing/?n=1", headers: headers)
            .responseDecodable(of: MoviesEntity.self) { response in

                if let movies = response.value {

                    successful(self.parse(movies))
                }
        }
    }
    
    func parse(_ movies: MoviesEntity) -> [Movie] {
        
        var result = [Movie]()
        
        if let movies = movies.movies {
            
            for movie in movies {
                
                if let dateString = movie.releaseDates?.first?.releaseDate {
                    
                    result.append(Movie(filmName: movie.filmName,
                                        filmId: "Film Identifier: \(movie.filmId ?? "None")",
                                        releaseDate: dateString,
                                        filmTrailer: movie.filmTrailer,
                                        description: movie.description,
                                        poster: movie.images?.poster?.oneEntity?.medium?.filmImage))
                }
            }
        }
        
        return result
    }
}
 
extension RestProvider {
    
    func requestPosterImage(url: String, completion: ((UIImage) -> Void)?) {
        
        if let cachedImage = imageCache.object(forKey: url as NSString) {
            
            completion?(cachedImage)
            
        } else {
            
            AF.request(url).response { response in
                
                if let data = response.value as? Data,
                    let image = UIImage(data: data) {
                    
                    self.imageCache.setObject(image, forKey: url as NSString)
                    completion?(image)
                }
            }
        }
    }
    
    func requestTrailer(_ url: String, completion: ((URL) -> Void)?) {
        
        if let cachedVideo = videoCache.object(forKey: url as NSString) {
            
            completion?(cachedVideo as URL)
            
        } else {
            
            AF.request(url).responseData{ (response) in
                
                if let data = response.value {

                    let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                    let videoURL = documentsURL.appendingPathComponent("trailer.mp4")
                    do {
                        try data.write(to: videoURL)
                        } catch {
                        print("Something went wrong!")
                    }
                    
                    self.videoCache.setObject(videoURL as NSURL, forKey: url as NSString)
                    completion?(videoURL)
                }
            }
        }
    }
}

extension RestProvider {
    
    func uploadImageToFireBase(_ image: UIImage) {
        
    }
    
    func uploadMovieToFireStore(_ movie: Movie) {
        
        let data: [String : String] = ["description" : movie.description ?? "",
                                       "film_id" : movie.filmId ?? "",
                                       "film_name" : movie.filmName ?? "",
                                       "film_trailer_url" : movie.filmTrailer ?? "",
                                       "poster_url" : movie.poster ?? "",
                                       "release_date" : movie.releaseDate ?? ""]
        var reference: DocumentReference? = nil
        reference = fireStore.collection("movie").addDocument(data: data) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(reference!.documentID)")
            }
        }
    }
}
