//
//  Movie.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

struct Movie {
    
    var filmName: String?
    var filmId: String?
    var releaseDate: String?
    var filmTrailer: String?
    var description: String?
    var poster: String?
}
