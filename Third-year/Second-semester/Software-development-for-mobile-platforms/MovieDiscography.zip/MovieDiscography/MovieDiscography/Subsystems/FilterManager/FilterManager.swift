//
//  FilterManager.swift
//  MovieDiscography
//
//  Created by local.home on 5/8/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import Foundation

enum FilterUserDefualtsKey: String {
    
    case currentFilter = "currentFilter"
    case isSorting = "isSorting"
}

struct FilterManager {
    
    static let shared = FilterManager()
    
    func currentFilter() -> FilterType? {
        
        if let string = UserDefaults.standard.object(forKey: FilterUserDefualtsKey.currentFilter.rawValue) as? String,
            let type = FilterType(rawValue: string) {
            
            return type
        }
        
        return nil
    }
    
    func saveFilter(_ filter: FilterType?) {
        
        UserDefaults.standard.set(filter?.rawValue, forKey: FilterUserDefualtsKey.currentFilter.rawValue)
    }
    
    func isSortingExist() -> Bool {
        
        return UserDefaults.standard.bool(forKey: FilterUserDefualtsKey.isSorting.rawValue)
    }
    
    func saveSortingExist(_ isSorting: Bool?) {
        
        UserDefaults.standard.set(isSorting, forKey: FilterUserDefualtsKey.isSorting.rawValue)
    }
}
