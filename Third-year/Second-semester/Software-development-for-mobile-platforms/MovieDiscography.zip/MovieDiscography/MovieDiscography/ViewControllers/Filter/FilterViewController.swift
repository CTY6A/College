//
//  FilterViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/8/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

enum FilterType: String {
    case yearBefore2000 = "by Year before 2000"
    case yearAfter2000 = "by Year after 2000"
    case havingPoster = "by having Poster"
}

class FilterViewController: UIViewController {
    
    @IBOutlet private weak var filterLabel: UILabel!
    @IBOutlet private weak var filterPickerView: UIPickerView!
    @IBOutlet private weak var sortingLabel: UILabel!
    @IBOutlet private weak var sortingPickerView: UIPickerView!
    
    @IBOutlet private weak var applyButton: UIButton!
    @IBOutlet private weak var resetButton: UIButton!
    
    private var filterData: [FilterType] = [.yearBefore2000, .yearAfter2000, .havingPoster]
    private var sortingData: [Bool] = [false, true]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configure()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

private extension FilterViewController {
    
    func configure() {
        
        configureNavigationItem()
        configureFilterViews()
        configureSortingViews()
        configureApplyButton()
        configureResetButton()
    }
    
    func configureNavigationItem() {
        
        navigationItem.title = "ui_filter".localized
    }
    
    func configureFilterViews() {
        
        filterLabel.attributedText = "ui_filter".localized.attributed
        
        filterPickerView.tag = filterPickerView.hashValue
        filterPickerView.dataSource = self
        filterPickerView.delegate = self
        
        let filter = FilterManager.shared.currentFilter()
        
        if  let filter = filter,
            let index = filterData.firstIndex(of: filter) {
            filterPickerView.selectRow(index,
                                     inComponent: 0,
                                     animated: true)
        }
    }
    
    func configureSortingViews() {
        
        sortingLabel.attributedText = "ui_sorting".localized.attributed
        
        sortingPickerView.tag = sortingPickerView.hashValue
        sortingPickerView.dataSource = self
        sortingPickerView.delegate = self
        
        let isSorting = FilterManager.shared.isSortingExist()
        
        if let index = sortingData.firstIndex(of: isSorting) {
            sortingPickerView.selectRow(index,
                                     inComponent: 0,
                                     animated: true)
        }
    }
    
    func configureApplyButton() {
        
        applyButton.setAttributedTitle("ui_apply".localized.attributed, for: .normal)
        applyButton.addTarget(self, action: #selector(applyAction(sender:)), for: .touchUpInside)
    }
    
    func configureResetButton() {
        
        resetButton.setAttributedTitle("ui_reset".localized.attributed, for: .normal)
        resetButton.addTarget(self, action: #selector(resetAction(sender:)), for: .touchUpInside)
    }
}

private extension FilterViewController {
    
    @objc func applyAction(sender: Any?) {
        
        let filter = filterData[filterPickerView.selectedRow(inComponent: 0)]
        let isSorting = sortingData[sortingPickerView.selectedRow(inComponent: 0)]
        
        let filterManager = FilterManager.shared
        filterManager.saveFilter(filter)
        filterManager.saveSortingExist(isSorting)
        
        navigationController?.popViewController(animated: true)
    }
    
    @objc func resetAction(sender: Any?) {
        
        let filterManager = FilterManager.shared
        filterManager.saveFilter(nil)
        filterManager.saveSortingExist(false)
        
        navigationController?.popViewController(animated: true)
    }
}

extension FilterViewController: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        switch pickerView.tag {
            
        case filterPickerView.hashValue:
            return filterData.count
            
        case sortingPickerView.hashValue:
            return sortingData.count
            
        default:
            return 0
        }
    }
}

extension FilterViewController: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        switch pickerView.tag {
            
        case filterPickerView.hashValue:
            return filterData[row].rawValue
            
        case sortingPickerView.hashValue:
            return sortingData[row] ? "True" : "False"
            
        default:
            return nil
        }
    }
}
