//
//  DiscographyViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class DiscographyViewController: MainViewController {
    
    @IBOutlet private weak var tableView: UITableView!
    
    private var movies = [Movie]()
    private var filteredMovies = [Movie]()
    
    override func viewWillAppear(_ animated: Bool) {
        
        configureNavigationitem()
        reload()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configuration()
        
        RestProvider.shared.requestMovies(successful: { [weak self] movies in
            
            self?.movies = movies
            
            self?.reload()
        })
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

private extension DiscographyViewController {
    
    func reload() {

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        if let currentFilter = FilterManager.shared.currentFilter() {
            
            filteredMovies = movies.filter({ movie in
                
                switch currentFilter {
                    
                case .havingPoster:
                    return movie.poster != nil
                    
                case .yearAfter2000:
                    
                    if let dateString = movie.releaseDate,
                        let date = dateFormatter.date(from: dateString),
                        let pointDate = dateFormatter.date(from: "2000-01-01") {
                        
                        return date > pointDate
                    }
                    
                    return false
                    
                case .yearBefore2000:
                    
                    if let dateString = movie.releaseDate,
                        let date = dateFormatter.date(from: dateString),
                        let pointDate = dateFormatter.date(from: "2000-01-01") {
                        
                        return date < pointDate
                    }
                    
                    return false
                }
            })
        } else {
            
            filteredMovies = movies
        }
        
        if FilterManager.shared.isSortingExist() {
            
            filteredMovies.sort { movie1, movie2 in
                
                if let dateString1 = movie1.releaseDate,
                    let dateString2 = movie2.releaseDate,
                    let date1 = dateFormatter.date(from: dateString1),
                    let date2 = dateFormatter.date(from: dateString2) {
                    
                    return date1 > date2
                }
                
                return false
            }
        }
        
        tableView.reloadData()
    }
}

private extension DiscographyViewController {
    
    func configuration() {
        
        configureNavigationitem()
        configureNavigationBarItems()
        configureTableView()
    }
    
    func configureNavigationitem() {
        
        navigationItem.title = "ui_discography".localized
    }
    
    func configureNavigationBarItems() {
        
        navigationItem.rightBarButtonItems = [UIBarButtonItem(image: UIImage(named: "Settings"),
                                                              style: .plain,
                                                              target: self,
                                                              action: #selector(settingsAction)),
                                              UIBarButtonItem(image: UIImage(named: "Filters"),
                                                              style: .plain,
                                                              target: self,
                                                              action: #selector(filterAction))]
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "plus"),
                                                           style: .plain,
                                                           target: self,
                                                           action: #selector(addMovieFromStoreAction))
    }
    
    func configureTableView() {
        
        let nib = UINib(nibName: "DiscographyTableViewCell",bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "DiscographyTableViewCell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
    }
}

extension DiscographyViewController {
    
    @objc private func settingsAction(sender: Any?) {
        
        let controller = SettingsViewController()
        
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @objc private func filterAction(sender: Any?) {
        
        let controller = FilterViewController()
        
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @objc private func addMovieFromStoreAction(sender: Any?) {
        
        if let movieObject = RealmStoreProvider.shared.movies?.last {
            
            let movie = Movie(filmName: movieObject.filmName,
                              filmId: movieObject.filmId,
                              releaseDate: movieObject.releaseDate,
                              filmTrailer: movieObject.filmTrailer,
                              description: movieObject.movieDescription,
                              poster: movieObject.poster)
            
            movies.append(movie)
            reload()
        }
    }
}

extension DiscographyViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredMovies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let dequeuedCell = tableView
            .dequeueReusableCell(withIdentifier: "DiscographyTableViewCell",
                                 for: indexPath)
        
        guard let cell = dequeuedCell as? DiscographyTableViewCell else {
            return dequeuedCell
        }
        
        let movie = filteredMovies[indexPath.row]
        
        cell.name = movie.filmName
        cell.filmId = movie.filmId
        cell.year = movie.releaseDate
        cell.movieDescription = movie.description
        cell.posterImageURL = movie.poster
        
        return cell
    }
}

extension DiscographyViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         
        let controller = DiscographyExtendedViewController()
        
        let movie = filteredMovies[indexPath.row]
        
        controller.movie = movie
        
        navigationController?.pushViewController(controller, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140.0
    }
}
