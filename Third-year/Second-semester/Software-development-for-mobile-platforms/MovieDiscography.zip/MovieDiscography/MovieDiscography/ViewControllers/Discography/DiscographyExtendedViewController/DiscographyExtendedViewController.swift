//
//  DiscographyExtendedViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/8/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit
import AVKit

class DiscographyExtendedViewController: UIViewController {
    
    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var filmNameLabel: UILabel!
    @IBOutlet private weak var filmIdLabel: UILabel!
    @IBOutlet private weak var releaseDateLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var uploadToServerButton: UIButton!
    @IBOutlet private weak var playTrailerButton: UIButton!
    @IBOutlet private weak var saveMovieToStoreButton: UIButton!
    
    private lazy var imagePickerController = UIImagePickerController()
    
    var movie: Movie?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configuration()
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

private extension DiscographyExtendedViewController {
    
    func configuration() {
        
        navigationItem.title = "ui_movie".localized
        posterImageView.image = UIImage(named: "Default")
        filmNameLabel.attributedText = movie?.filmName?.attributed
        releaseDateLabel.attributedText = movie?.releaseDate?.attributed
        filmIdLabel.attributedText = movie?.filmId?.attributed
        descriptionLabel.attributedText = movie?.description?.attributed
        if let url = movie?.poster {
            
            RestProvider.shared.requestPosterImage(url: url) { [weak self] image in
                
                self?.posterImageView.image = image
            }
        } else {
            posterImageView.image = UIImage(named: "Default")
        }
        
        configurePlayTrailerButton()
        configureUploadToServerButton()
        configureStoreToLocalButton()
    }
    
    func configurePlayTrailerButton() {
        
        playTrailerButton.setAttributedTitle("ui_play_trailer".localized.attributed, for: .normal)
        playTrailerButton.addTarget(self, action: #selector(playTrailerAction(sender:)), for: .touchUpInside)
    }
    
    func configureUploadToServerButton() {
        
        uploadToServerButton.setAttributedTitle("ui_upload_to_server".localized.attributed, for: .normal)
        uploadToServerButton.addTarget(self, action: #selector(uploadToServerAction(sender:)), for: .touchUpInside)
    }
    
    func configureStoreToLocalButton() {
        
        saveMovieToStoreButton.setAttributedTitle("ui_save_local".localized.attributed, for: .normal)
        saveMovieToStoreButton.addTarget(self, action: #selector(saveToStoreAction(share:)), for: .touchUpInside)
    }
}

private extension DiscographyExtendedViewController {
    
    @objc func playTrailerAction(sender: Any?) {
        
        if let url = movie?.filmTrailer {
            RestProvider.shared.requestTrailer(url) { [weak self] videoUrl in
                
                self?.playVideo(with: videoUrl as NSURL)
            }
        } else {
            
            RestProvider.shared
                .requestTrailer("https://wolverine.raywenderlich.com/content/ios/tutorials/video_streaming/foxVillage.mp4")
                { [weak self] videoUrl in
                
                self?.playVideo(with: videoUrl as NSURL)
            }
        }
    }
    
    @objc func uploadToServerAction(sender: Any?) {
        
        if let movie = self.movie {
            
            RestProvider.shared.uploadMovieToFireStore(movie)
            
            let alert = UIAlertController(title: "ui_uploaded_successfully".localized,
                                          message: nil,
                                          preferredStyle: .alert)
            let closeAction = UIAlertAction(title: "ui_ok".localized,
                                            style: .default,
                                            handler: nil)
            alert.addAction(closeAction)
            
            present(alert, animated: true, completion: nil)
        }
    }
    
    @objc func saveToStoreAction(share: Any?) {
        
        let object = MovieObject()
        
        object.filmName = movie?.filmName ?? ""
        object.filmId = movie?.filmId ?? ""
        object.releaseDate = movie?.releaseDate ?? ""
        object.filmTrailer = movie?.filmTrailer ?? ""
        object.movieDescription = movie?.description ?? ""
        object.poster = movie?.poster ?? ""
        
        RealmStoreProvider.shared.writeToStore(object: object)
    }
}

extension DiscographyExtendedViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let videoURL = info[UIImagePickerController.InfoKey.referenceURL] as? NSURL {

            imagePickerController.dismiss(animated: true, completion: nil)
            
            playVideo(with: videoURL)
        }
    }
    
    func playVideo(with videoUrl: NSURL) {
        
        let player = AVPlayer(url: videoUrl as URL)
        
        let playerController = PlayerViewController()
        playerController.player = player
        
        navigationController?.pushViewController(playerController, animated: true)
    }
}
