//
//  DiscographyTableViewCell.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class DiscographyTableViewCell: UITableViewCell {

    @IBOutlet private weak var posterImageView: UIImageView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var yearLabel: UILabel!
    @IBOutlet private weak var imdbLabel: UILabel!
    @IBOutlet private weak var descriptionlabel: UILabel!
    
    var posterImageURL: String? {
        willSet(value) {
            
            if let url = value {
                
                RestProvider.shared.requestPosterImage(url: url) { [weak self] image in
                    
                    self?.posterImageView.image = image
                }
            } else {
                
                posterImageView.image = UIImage(named: "Default")
            }
        }
    }
    
    var name: String? {
        get {
            
            return nameLabel.text
        }
        set(value) {
            
            nameLabel.attributedText = value?.attributed
        }
    }
    
    var year: String? {
        get {
            
            return yearLabel.text
        }
        set(value) {
            
            yearLabel.attributedText = value?.attributed
        }
    }
    
    var filmId: String? {
        get {
            
            return imdbLabel.text
        }
        set(value) {
            
            imdbLabel.attributedText = value?.attributed
        }
    }
    
    var movieDescription: String? {
        get {
            
            return descriptionlabel.text
        }
        set(value) {
            
            descriptionlabel.attributedText = value?.attributed
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        posterImageView?.image = UIImage(named: "Default")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
