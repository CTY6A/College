//
//  FontsViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class FontsViewController: UIViewController {
    
    @IBOutlet private weak var fontPickerView: UIPickerView!
    @IBOutlet private weak var sizePickerView: UIPickerView!
    @IBOutlet private weak var applyButton: UIButton!
    
    private let fonts = UIFont.fontNames(forFamilyName: "Avenir")
    
    private let sizes:[CGFloat] = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    private let sizesStrings = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configure()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func applyAction(_ sender: Any) {
        
        let font = UIFont(name: fonts[fontPickerView.selectedRow(inComponent: 0)],
                          size: sizes[sizePickerView.selectedRow(inComponent: 0)])
        FontsManager.shared.saveFont(font)
        
        navigationController?.popViewController(animated: true)
    }
}

private extension FontsViewController {
    
    func configure() {
        
        configureApplyButton()
        configureFontPickerView()
        configureSizePickerView()
        configureNavigationItem()
    }
    
    private func configureNavigationItem() {
        
        navigationItem.title = "ui_fonts".localized
    }
    
    func configureFontPickerView() {
        
        fontPickerView.tag = fontPickerView.hashValue
        fontPickerView.dataSource = self
        fontPickerView.delegate = self
        
        let font = FontsManager.shared.currentFont()
        
        if let index = UIFont.fontNames(forFamilyName: "Avenir").firstIndex(of: font.fontName) {
            fontPickerView.selectRow(index,
                                     inComponent: 0,
                                     animated: true)
        }
    }
    
    func configureSizePickerView() {
        
        sizePickerView.tag = sizePickerView.hashValue
        sizePickerView.dataSource = self
        sizePickerView.delegate = self
        
        let font = FontsManager.shared.currentFont()
        
        if let index = sizes.firstIndex(of: font.pointSize) {
            sizePickerView.selectRow(index,
                                     inComponent: 0,
                                     animated: true)
        }
    }
    
    func configureApplyButton() {
        
        applyButton.setAttributedTitle("ui_apply".localized.attributed, for: .normal)
    }
}

extension FontsViewController: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        switch pickerView.tag {
            
        case fontPickerView.hashValue:
            return fonts.count
            
        case sizePickerView.hashValue:
            return sizesStrings.count
            
        default:
            return 0
        }
    }
}

extension FontsViewController: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        switch pickerView.tag {
            
        case fontPickerView.hashValue:
            return fonts[row]
            
        case sizePickerView.hashValue:
            return sizesStrings[row]
            
        default:
            return nil
        }
    }
}
