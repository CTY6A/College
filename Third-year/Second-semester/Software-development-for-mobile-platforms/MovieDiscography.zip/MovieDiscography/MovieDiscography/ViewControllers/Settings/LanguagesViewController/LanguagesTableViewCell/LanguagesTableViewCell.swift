//
//  LanguagesTableViewCell.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class LanguagesTableViewCell: UITableViewCell {
    
    @IBOutlet private weak var checkImage: UIImageView!
    @IBOutlet private weak var languageLabel: UILabel!
    
    var language: String? {
        get {
            
            return languageLabel.text
        }
        set(value) {
            
            languageLabel.attributedText = value?.attributed
        }
    }
    
    var isCurrent: Bool {
        get {
            return checkImage.image == UIImage(named: "round_checked")
        }
        set(value) {
            
            checkImage.image = value ? UIImage(named: "round_checked") : UIImage(named: "round_disabled")
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
