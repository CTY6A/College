//
//  SettingsViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class SettingsViewController: MainViewController {
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        
        configureNavigationItem()
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configure()
    }
}

extension SettingsViewController {
    
    func configure() {
        
        configureTableView()
        configureNavigationItem()
        tableView.reloadData()
    }
    
    func configureNavigationItem() {
        
        navigationItem.title = "ui_settings".localized
    }
    
    func configureTableView() {
        
        let nib = UINib(nibName: "SettingsTableViewCell",bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "SettingsTableViewCell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
    }
}

extension SettingsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let dequeuedCell = tableView
            .dequeueReusableCell(withIdentifier: "SettingsTableViewCell",
                                 for: indexPath)
        
        guard let cell = dequeuedCell as? SettingsTableViewCell else {
            return dequeuedCell
        }
        
        switch indexPath.row {
            
            // languages
        case 0:
            
            cell.title = "ui_languages".localized
            cell.content = LanguageManager.shared.currentLanguageString()
            
            return cell
            
            //fonts
        case 1:
            
            let font = FontsManager.shared.currentFont()
            
            cell.title = "ui_fonts".localized
            cell.content = "\(font.fontName) \(font.pointSize)"
            
            return cell
            
        default:
            return dequeuedCell
        }
    }
}

extension SettingsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
            
            // languages
        case 0:
            
            let controller = LanguagesViewController()
            
            navigationController?.pushViewController(controller, animated: true)
            
            //fonts
        case 1:
            
            let controller = FontsViewController()
            
            navigationController?.pushViewController(controller, animated: true)
            
        default:
            return
        }
    }
}
