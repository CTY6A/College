//
//  LanguagesViewController.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class LanguagesViewController: MainViewController {
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewWillAppear(_ animated: Bool) {
        
        configureNavigationItem()
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configure()
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension LanguagesViewController {
    
    func configure() {
        
        configureNavigationItem()
        configureTableView()
    }
    
    func configureNavigationItem() {
        
        navigationItem.title = "ui_languages".localized
    }
    
    func configureTableView() {
        
        let nib = UINib(nibName: "LanguagesTableViewCell",bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "LanguagesTableViewCell")
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
    }
}

extension LanguagesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LanguageManager.shared.availableLanguageList().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let dequeuedCell = tableView
            .dequeueReusableCell(withIdentifier: "LanguagesTableViewCell",
                                 for: indexPath)
        
        guard let cell = dequeuedCell as? LanguagesTableViewCell else {
            return dequeuedCell
        }
        
        let language = LanguageManager.shared.availableLanguageList()[indexPath.row]
        let selected = LanguageManager.shared.currentLanguageIndex() == indexPath.row
        
        cell.language = language
        cell.isCurrent = selected
        
        return cell
    }
}

extension LanguagesViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        LanguageManager.shared.saveLanguage(by: indexPath.row)
        
        navigationController?.popViewController(animated: true)
    }
}
