//
//  SettingsTableViewCell.swift
//  MovieDiscography
//
//  Created by local.home on 5/7/20.
//  Copyright © 2020 polina.sergey. All rights reserved.
//

import UIKit

class SettingsTableViewCell: UITableViewCell {

    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    
    var title: String? {
        get {
            
            return titleLabel.text
        }
        set(value) {
            
            titleLabel.attributedText = value?.attributed
        }
    }
    var content: String? {
        get {
            
            return contentLabel.text
        }
        set(value) {
            
            contentLabel.attributedText = value?.attributed
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
